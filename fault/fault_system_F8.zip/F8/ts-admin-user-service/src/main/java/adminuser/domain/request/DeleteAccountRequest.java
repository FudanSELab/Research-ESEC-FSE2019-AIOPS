package adminuser.domain.request;

public class DeleteAccountRequest {
    private String loginId;
    private String accountId;

    public DeleteAccountRequest(){

    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}
