package fdse.microservice.domain;


public class QueryForStationId {

    private String name;

    public QueryForStationId(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
