package preserveOther.domain;

public class CheckInfo {

    private String accountId;

    public CheckInfo() {
        //Default Constructor
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}
