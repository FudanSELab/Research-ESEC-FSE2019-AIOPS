package preserveOther.domain;


public class QueryForId {

    private String name;

    public QueryForId(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
