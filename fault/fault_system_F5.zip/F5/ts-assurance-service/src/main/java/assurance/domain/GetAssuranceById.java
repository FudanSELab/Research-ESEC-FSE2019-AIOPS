package assurance.domain;

public class GetAssuranceById {

    private String assuranceId;

    public String getAssuranceId() {
        return assuranceId;
    }

    public void setAssuranceId(String assuranceId) {
        this.assuranceId = assuranceId;
    }

}
