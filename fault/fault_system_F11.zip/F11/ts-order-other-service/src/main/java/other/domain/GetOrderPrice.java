package other.domain;

public class GetOrderPrice {

    private String orderId;

    public GetOrderPrice() {
        //Default Constructor
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
