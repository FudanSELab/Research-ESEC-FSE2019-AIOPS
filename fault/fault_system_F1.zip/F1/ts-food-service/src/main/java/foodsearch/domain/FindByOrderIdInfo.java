package foodsearch.domain;

public class FindByOrderIdInfo {

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    String orderId;
}
