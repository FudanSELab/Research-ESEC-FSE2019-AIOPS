package launcher.service;

/**
 * Created by fdse-jichao on 2017/8/13.
 */
public interface LauncherService {

    public void doErrorQueue(String email,String password);

}
