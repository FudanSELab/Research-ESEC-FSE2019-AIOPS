package main

func sayHello2(address string) string {
	return "[Ts-News-Service] Get Message From Client: " + address
}
